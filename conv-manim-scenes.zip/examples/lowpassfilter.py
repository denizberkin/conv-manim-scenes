import numpy as np
from scipy.io import wavfile

wav_path = "data/input.wav"
sample_rate, data = wavfile.read(wav_path)

# one channel for simplicity
if len(data.shape) > 1:
    data = data[:, 0]

# normalize to range [-1, 1]
original_signal = data / np.max(np.abs(data))
# larger kernel size, more smoothing
kernel_size = 20
low_pass_kernel = np.ones(kernel_size) / kernel_size  # sums to 1

# apply convolution
smoothed_signal = np.convolve(original_signal, low_pass_kernel, mode="same")

# save output
output_path = "data/output_lowpass.wav"
wavfile.write(output_path, sample_rate, smoothed_signal.astype(np.float32))
