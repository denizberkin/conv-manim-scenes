import numpy as np
from scipy.io import wavfile

wav_path = "data/input.wav"
sample_rate, data = wavfile.read(wav_path)

# one channel for simplicity
if len(data.shape) > 1:
    data = data[:, 0]

# normalize to range [-1, 1]
original_signal = data / np.max(np.abs(data))

delay_seconds = 0.5
delay_samples = int(delay_seconds * sample_rate)

echo_kernel = np.zeros(delay_samples * 3)
echo_kernel[0] = 1.0  # Original sound
echo_kernel[delay_samples] = 0.5  # First echo at 0.5s
echo_kernel[delay_samples * 2] = 0.25  # Second echo at 1.0s

# apply convolution, mode=full to capture full echo effect, longer than original
smoothed_signal = np.convolve(original_signal, echo_kernel, mode="full")

# save output
output_path = "data/output_echo.wav"
wavfile.write(output_path, sample_rate, smoothed_signal.astype(np.float32))
